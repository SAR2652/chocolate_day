<?php $__env->startSection('content'); ?>
<div class="container">
        <table id="cart" class="table table-hover table-condensed">                
                        <thead>
                            <tr>
                                <th style="width:50%">Product</th>
                                <th style="width:10%">Price</th>
                                <th style="width:8%">To</th>
                                <th style="width:22%" class="text-center">Subtotal</th>
                                <th style="width:10%"></th>
                            </tr>
                        </thead>
                        <?php
                           $total=0;
                        ?>

                        <?php $__currentLoopData = $chocos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td data-th="Product">
                                    <div class="row">
                                    <div class="col-sm-2 hidden-xs"><img src="<?php echo e(asset('img/').'/'.$choco->img_path); ?>" alt="..." class="img-responsive"/></div>
                                        <div class="col-sm-10">
                                        <h4 class="nomargin"><?php echo e($choco->category); ?></h4>
                                            <p></p>
                                        </div>
                                    </div>
                                </td>
                            <td data-th="Price"><?php echo e($choco->price); ?></td>
                                <td data-th="Quantity">
                                        <h4 class="nomargin"><?php echo e($choco->receiver); ?></h4>
                                </td>
                            <td data-th="Subtotal" class="text-center"><?php echo e($choco->price); ?></td>
                            <?php
                                $total = $total+ $choco->price;
                            ?>
                                <td class="actions" data-th="">
                                    <button class="btn btn-info btn-sm"><i class="fa fa-refresh"></i></button>
                                    <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></button>								
                                </td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <tfoot>
                            <tr class="visible-xs">
                                <td class="text-center"><strong>Total 150</strong></td>
                            </tr>
                            <tr>
                                <td><a href="/" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
                                <td colspan="2" class="hidden-xs"></td>
                            <td class="hidden-xs text-center"><strong>Total <?php echo e($total); ?></strong></td>
                            <td><a href="<?php echo e(route('thank_you')); ?>" class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></a></td>
                            </tr>
                        </tfoot>
                    </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>